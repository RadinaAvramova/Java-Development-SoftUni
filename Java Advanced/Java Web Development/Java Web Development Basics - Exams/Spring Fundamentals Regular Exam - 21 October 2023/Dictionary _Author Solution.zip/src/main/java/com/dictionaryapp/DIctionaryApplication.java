package com.dictionaryapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DIctionaryApplication {

    public static void main(String[] args) {
        SpringApplication.run(DIctionaryApplication.class, args);
    }
}
