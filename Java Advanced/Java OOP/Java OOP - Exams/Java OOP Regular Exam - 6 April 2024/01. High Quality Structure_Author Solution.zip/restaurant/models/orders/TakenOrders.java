package restaurant.models.orders;

import java.util.Collection;

public interface TakenOrders {
    Collection<String> getOrdersList();
}
