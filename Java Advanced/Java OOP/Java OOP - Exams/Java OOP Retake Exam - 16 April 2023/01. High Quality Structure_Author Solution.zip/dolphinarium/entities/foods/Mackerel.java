package dolphinarium.entities.foods;

public class Mackerel extends BaseFood{

    private final static int CALORIES_AMOUNT = 305;
    public Mackerel() {
        super(CALORIES_AMOUNT);
    }

}
