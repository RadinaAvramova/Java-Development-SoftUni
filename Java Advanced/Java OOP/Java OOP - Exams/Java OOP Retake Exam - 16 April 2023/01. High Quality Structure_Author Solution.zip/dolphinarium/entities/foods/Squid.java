package dolphinarium.entities.foods;

public class Squid extends BaseFood{

    private final static int CALORIES_AMOUNT = 175;
    public Squid() {
        super(CALORIES_AMOUNT);
    }

}
