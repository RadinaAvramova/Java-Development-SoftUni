package dolphinarium.entities.foods;

public interface Food {

//    String getName();

    int getCalories();

}
