package dolphinarium.entities.foods;

public class Herring extends BaseFood {

    private final static int CALORIES_AMOUNT = 200;
    public Herring() {
        super(CALORIES_AMOUNT);
    }




}
