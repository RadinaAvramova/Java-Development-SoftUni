package shelter;

import java.util.ArrayList;
import java.util.List;

public class Shelter {
    private List<Animal> data;
    private int capacity;

    public Shelter(int capacity){
        this.capacity = capacity;
        this.data = new ArrayList<>();

    }
    public void add(Animal animal){
        if (this.data.size() < capacity){
            this.data.add(animal);
        }
    }
    public boolean remove(String name){
        return this.data.removeIf(a -> a.getName().equals(name));

    }
    public Animal getAnimal(String name, String caretaker){
        return this.data.stream()
                .filter(p -> p.getName().equals(name) && p.getCaretaker().equals(caretaker))
                .findAny().orElse(null);
    }
    public Animal getOldestAnimal(){
        int oldestAge = 0;
        Animal oldest = null;

        for (Animal animal : this.data) {

            if (animal.getAge() > oldestAge){
                oldestAge = animal.getAge();
                oldest = animal;
            }
        }
        return oldest;

    }
    public int getCount(){
        return this.data.size();
    }
    public String getStatistics(){
        StringBuilder out = new StringBuilder("The shelter has the following animals:");
        for (Animal currentAnimal : data){
            out.append("\n");
            out.append(currentAnimal.getName());
            out.append(" ");
            out.append(currentAnimal.getCaretaker());
        }
        return out.toString();
    }
}
