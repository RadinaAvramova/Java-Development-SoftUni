import org.junit.Test;
import spaceCrafts.LaunchPad;
import spaceCrafts.Spacecraft;

import static org.junit.Assert.assertEquals;

public class T06ValidateGetHaviestSpacecraftMethod {
    @Test
    public void testGetHeaviestSpacecraft() {
        // Create a LaunchPad object with a list of spacecrafts
        LaunchPad launchPad = new LaunchPad("Test LaunchPad", 3);
        Spacecraft spacecraft1 = new Spacecraft("Spacecraft 1", "Mission Type 1", "target", "objective", 1000);
        Spacecraft spacecraft2 = new Spacecraft("Spacecraft 2", "Mission Type 2", "target", "objective", 1500);
        launchPad.addSpacecraft(spacecraft1);
        launchPad.addSpacecraft(spacecraft2);

        // Test the getHeaviestSpacecraft method
        String heaviestSpacecraft = launchPad.getHeaviestSpacecraft();
        assertEquals("Spacecraft 2 - 1500kg.", heaviestSpacecraft);
    }
}

