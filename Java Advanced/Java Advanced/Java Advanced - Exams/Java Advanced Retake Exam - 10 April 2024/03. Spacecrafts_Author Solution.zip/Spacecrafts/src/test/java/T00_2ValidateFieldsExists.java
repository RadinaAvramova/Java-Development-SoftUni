import org.junit.Assert;
import org.junit.Test;

import java.lang.reflect.Field;

public class T00_2ValidateFieldsExists {
    private static final String FIELD_NOT_PRESENT_ERROR_MESSAGE = "The field '%s.%s' does not exist!";

    private class ExpField {
        String name;

        public ExpField(String name) {
            this.name = name;
        }
    }

    @Test
    public void validateClassFields() {
        Class clazzFirstType = getType("Spacecraft");
        ExpField[] fieldsFirstType = new ExpField[]{
                new ExpField("name"),
                new ExpField("missionType"),
                new ExpField("target"),
                new ExpField("objective"),
                new ExpField("weight"),
        };

        for (ExpField field : fieldsFirstType) {
            validateField(clazzFirstType, field);
        }


        Class clazzSecondType = getType("LaunchPad");
        ExpField[] fieldsSecondType = new ExpField[]{
                new ExpField("spacecrafts"),
                new ExpField("name"),
                new ExpField("capacity"),
        };

        for (ExpField field : fieldsSecondType) {
            validateField(clazzSecondType, field);
        }
    }

    private void validateField(Class clazz, ExpField expField) {
        String expectedName = expField.name;

        // Returns null if the field does not exist
        Field actualField = getField(clazz, expectedName);

        // Tests whether the field exist
        String nameMessage = String.format(FIELD_NOT_PRESENT_ERROR_MESSAGE, clazz.getSimpleName(), expectedName);
        Assert.assertNotNull(nameMessage, actualField);
    }

    private Field getField(Class clazz, String expectedName) {
        Field field = null;
        try {
            field = clazz.getDeclaredField(expectedName);
        } catch (NoSuchFieldException e) {
        }

        return field;
    }


    private static Class getType(String name) {
        Class clazz = Classes.allClasses.get(name);

        return clazz;
    }
}