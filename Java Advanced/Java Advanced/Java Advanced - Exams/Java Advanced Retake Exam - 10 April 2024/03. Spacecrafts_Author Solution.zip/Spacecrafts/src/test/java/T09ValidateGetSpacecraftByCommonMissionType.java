import org.junit.Test;
import spaceCrafts.LaunchPad;
import spaceCrafts.Spacecraft;

import java.util.List;

import static org.junit.Assert.assertEquals;

public class T09ValidateGetSpacecraftByCommonMissionType {

    @Test
    public void testGetSpacecraftsByMissionType() {
        // Create a LaunchPad object with a list of spacecrafts
        LaunchPad launchPad = new LaunchPad("Test LaunchPad", 3);
        Spacecraft spacecraft1 = new Spacecraft("Spacecraft 1", "Mission Type 1" , "Mars", "objective1",1000);
        Spacecraft spacecraft2 = new Spacecraft("Spacecraft 2", "Mission Type 2" , "Venus", "objective2",1500);
        Spacecraft spacecraft3 = new Spacecraft("Spacecraft 3", "Mission Type 1" , "Uranus", "objective3",1200);
        launchPad.addSpacecraft(spacecraft1);
        launchPad.addSpacecraft(spacecraft2);
        launchPad.addSpacecraft(spacecraft3);

        // Test the getSpaceCraftsByMissionType method for Mission Type 1
        List<Spacecraft> spacecraftsByType1 = launchPad.getSpacecraftsByMissionType("Mission Type 1");
        assertEquals(2, spacecraftsByType1.size());
        assertEquals("Spacecraft 1", spacecraftsByType1.get(0).getName());
        assertEquals("Spacecraft 3", spacecraftsByType1.get(1).getName());

        // Test the getSpaceCraftsByMissionType method for Mission Type 2
        List<Spacecraft> spacecraftsByType2 = launchPad.getSpacecraftsByMissionType("Mission Type 2");
        assertEquals(1, spacecraftsByType2.size());
        assertEquals("Spacecraft 2", spacecraftsByType2.get(0).getName());

        // Test the getSpaceCraftsByMissionType method for non-existing mission type
        List<Spacecraft> spacecraftsByNonExistingType = launchPad.getSpacecraftsByMissionType("There are no spacecrafts to respond this criteria.");
        assertEquals(0, spacecraftsByNonExistingType.size());
    }
}
